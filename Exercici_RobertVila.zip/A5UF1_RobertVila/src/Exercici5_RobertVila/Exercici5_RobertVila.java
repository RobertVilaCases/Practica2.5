package Exercici5_RobertVila;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.util.Scanner;

public class Exercici5_RobertVila {

	public static void main(String[] args) throws IOException {

		Scanner lector = new Scanner(System.in);

		int menu = 0;

		System.out.println("\n1.Crear Fitxer Empleats" + "\n\n2.Mostrar Empleats" + "\n\n3.Modificar Salari" + "\n\n4.Sortir");

		menu = lector.nextInt();

		switch (menu) {

		case 1:

			File fitxer = new File("aleatoriEmpleat.txt");

			RandomAccessFile file = new RandomAccessFile(fitxer, "rw");

			String cognom[] = { "FERNANDEZ", "GIL", "LOPEZ", "RAMOS", "SEVILLA", "CASILLA", "REY" };

			double salari[] = { 1000.45, 2400.60, 3000.0, 1500.56, 2200.0, 1435.87, 2000.0 };

			int dep[] = { 10, 20, 10, 10, 30, 30, 20 };

			StringBuffer buffer = null;

			int n = cognom.length;

			for (int i = 0; i < n; i++) {

				file.writeInt(i + 1);

				buffer = new StringBuffer(cognom[i]);

				buffer.setLength(10);

				file.writeChars(buffer.toString());

				file.writeInt(dep[i]);

				file.writeDouble(salari[i]);

			}

			file.close();

			System.out.println("\nEl fitxer s'ha creat correctament.");

			main(null);

			break;

		case 2:

			File fitxer2 = new File("aleatoriEmpleat.txt");

			RandomAccessFile file2 = new RandomAccessFile(fitxer2, "r");

			int id, dep2, posicio;

			Double salari2;

			char cognom2[] = new char[10], aux;

			posicio = 0;

			for (;;) {

				file2.seek(posicio);

				id = file2.readInt();

				for (int i = 0; i < cognom2.length; i++) {

					aux = file2.readChar();

					cognom2[i] = aux;

				}

				String cognoms = new String(cognom2);

				dep2 = file2.readInt();

				salari2 = file2.readDouble();

				if (id > 0) {

					System.out.printf("ID: %s, Cognoms: %s, Departament: %d, Salari: %.2f %n", id, cognoms.trim(), dep2, salari2);

					posicio = posicio + 36;

					if (file2.getFilePointer() == file2.length())
						
						break;

				}

			}

			main(null);
			
			break;

		case 3:

			try {

				int identificador;

				double importSalari;

				File fitxer3 = new File("aleatoriEmpleat.txt");

				String cognom5[] = { "FERNANDEZ", "GIL", "LOPEZ", "RAMOS", "SEVILLA", "CASILLA", "REY" };

				double salari5[] = { 1000.45, 2400.60, 3000.0, 1500.56, 2200.0, 1435.87, 2000.0 };

				RandomAccessFile file3 = new RandomAccessFile(fitxer3, "rw");

				
				System.out.println("\nIntrodueix un identificador...");

				identificador = lector.nextInt();

				
				System.out.println("\nIntrodueix un import...");

				importSalari = lector.nextDouble();

				
				int identificadorEmpleat = identificador;

				double cadena;

				cadena = file3.readDouble();

				long a = (((identificadorEmpleat - 1) * 36) + 28);

				double x = salari5[identificadorEmpleat - 1];

				file3.seek(a);

				file3.writeDouble(importSalari + x);

				
				
				
				
				int id10, dep10, posicio10;

				Double salari10;

				char cognom10[] = new char[10], aux10;

				posicio10 = (identificadorEmpleat - 1) * 36;

				
				for (;;) {

					file3.seek(posicio10);

					id10 = file3.readInt();

					for (int i = 0; i < cognom10.length; i++) {

						aux10 = file3.readChar();

						cognom10[i] = aux10;

					}

					String cognoms = new String(cognom10);

					dep10 = file3.readInt();

					salari10 = file3.readDouble();

					if (id10 > 0) {

						System.out.println("\nSalari Antic: " + x);

						System.out.printf("\nCognom: %s, Salari: %.2f %n", cognoms.trim(), salari10);

						posicio10 = posicio10 + (identificadorEmpleat - 1) * 36;

						break;

					}

				}

				file3.close();

			} catch (Exception e) {

				System.out.println("\nError, aquest identificador no existeix.");
			}

			main(null);

			break;

		case 4:

			System.out.println("\nFins aviat.");
			
			break;

		}

	}
}








